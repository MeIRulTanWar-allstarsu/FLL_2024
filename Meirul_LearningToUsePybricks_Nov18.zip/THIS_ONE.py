from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()
from MineStemLib  import resetHeading 
from MineStemLib import myHeading

"Defining Variables"
#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheel's axles track size.
#This is the distance in mm between the center of each side wheel.  
wheel_axle_dist = 125
"Creating objects"
myPrimeHub = PrimeHub()
left_wheel_motor =  Motor (Port.A)
right_wheel_motor = Motor (Port.B,Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor (Port.C)
right_attachment_motor = Motor (Port.D)
#left_color_sensor = ColorSensor (Port.E)
#right_color_sensor = ColorSensor (Port.F)
"creating objects and using their commands"
drive_base= DriveBase(left_wheel_motor, right_wheel_motor, wheel_diameter=wheel_dia, axle_track=wheel_axle_dist)
drive_base.use_gyro(True)
"writing/calling Functions"
def leftAttachment(speed,angle):
    left_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)
def rightAttachment(speed,angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)

def run1():
    leftAttachment(50, 180)
    rightAttachment(150, 90)

    
def run2():
    drive_base.straight(783)
    drive_base.turn(90)
    drive_base.straight(100)
    drive_base.straight(980)
    drive_base.turn(50)
    drive_base.straight(100)
    drive_base.straight(-50)
    drive_base.turn(-50)
    drive_base.straight(300)
    drive_base.turn(-40)
    drive_base.straight(200)
    drive_base.straight(-50)
    drive_base.turn(-60)
    drive_base.straight(-600)
    drive_base.stop()
#run2()
def run3():
    """Drive to first mission"""
    drive_base.straight(670)
    drive_base.turn(-50)
    """Push lever on first mission"""
    rightAttachment(100, -200)
    rightAttachment(100, 200)
    """Drive around sound mixer"""
    drive_base.straight(-40)
    drive_base.turn(50)
    drive_base.straight(55)
    drive_base.turn(90)

    """Drive to second mission"""
    drive_base.turn(-35)
    drive_base.straight(940)
    drive_base.turn(50)
    drive_base.straight(100)
    drive_base.straight(-50)
    drive_base.turn(-50)
    drive_base.straight(300)
    drive_base.turn(-40)
    drive_base.straight(200)
    drive_base.straight(-50)
    drive_base.turn(-60)
    drive_base.straight(-600)
    drive_base.stop()
#run3()
""
def run4():
    
    leftAttachment(75, 130)
    drive_base.straight(382)
    drive_base. turn(30)
    
    leftAttachment(75, 130)
    drive_base.straight(-300)
#run4()
def run5():
    drive_base.straight(506)
    drive_base.turn(20)
    leftAttachment(125, 190)
    drive_base.straight(-175)
    leftAttachment(125, -190)
    drive_base.straight(-125)
    drive_base.turn(-50)
    drive_base.straight(250)
    
    drive_base.straight(290)
    drive_base.turn(-50)
    drive_base.straight(230)
    drive_base.turn(-45)
    rightAttachment(120, -170)
    rightAttachment(120, 170)
    drive_base.turn(116)
    drive_base.straight(963)
    drive_base.turn(90)
    drive_base.straight(550)
#run5()
def run6():
    drive_base.straight(700)
    drive_base.turn(90)
    drive_base.straight(500)
    drive_base.turn(50)
    drive_base.straight(60)
    drive_base.turn(40)
    drive_base.straight(78)   
    leftAttachment(600,1475)
    drive_base.straight(-172)
    drive_base.turn(-90)
    drive_base.straight(815)
    drive_base.turn(90)
    drive_base.straight(650)
run6()

    
    



    
    
    
    
  

    
    
    
    
    

    

