""" Importing Libraries """
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor,UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Icon, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
 
from MineStemLib import resetHeading
from MineStemLib import myHeading

""" Creating Objects """
myPrimeHub = PrimeHub()

left_wheel_motor = Motor(Port.A)
right_wheel_motor = Motor(Port.B,Direction.COUNTERCLOCKWISE)
left_attachment_motor = Motor(Port.C)
right_attachment_motor = Motor(Port.D)
#left_color_sensor = ColorSensor(Port.E)
#right_color_sensor = ColorSensor(Port.F)

""" Writing/Calling Functions """
def leftAttachment(speed,angle):
    left_attachment_motor.run_angle(speed,angle,then=Stop.COAST, wait=True)

def rightAttachment(speed,angle):
    right_attachment_motor.run_angle(speed,angle,then=Stop.COAST,wait=True)

""" Defining Variables """
#Diameter of the wheels in mm
wheel_dia = 49.5
#The wheels axle track size. This is the distance
#in mm between the center of each side wheel.
wheel_axle_dist = 125

""" Creating Objects and using their commands """
drive_base = DriveBase(left_wheel_motor, right_wheel_motor, wheel_diameter=wheel_dia, axle_track=wheel_axle_dist) 
drive_base.use_gyro(True)

#leftAttachment(50, 180)
#rightAttachment(150, 90)






def run1():
    leftAttachment(50, 180)
    rightAttachment(150, 90)
    leftAttachment(80, 360)
    leftAttachment(20, -90)
    rightAttachment(100, -135)

#run1()


def run2():
    drive_base.settings(straight_speed=600,straight_acceleration=300,turn_rate=400,turn_acceleration=300)
    leftAttachment(100,100)
    leftAttachment(100,-100)
    drive_base.straight(260)
    drive_base.turn(90)
    drive_base.straight(420)
    drive_base.turn(90)
    drive_base.straight(5)
    leftAttachment(150,138)
    drive_base.straight(-15)
    leftAttachment(150,-138)
    drive_base.turn(-90)
    drive_base.straight(800)
    drive_base.turn(90)
    drive_base.straight(230)
    drive_base.turn(90)
    drive_base.straight(45)
    leftAttachment(150,107.5)
    drive_base.straight(-76)
    leftAttachment(150,-107.5)
    leftAttachment(150,100)
    leftAttachment(150,-100)

    drive_base.straight(65)
    leftAttachment(100,-138)

    drive_base.straight(380)
    drive_base.turn(-45)
    leftAttachment(100,197)
    leftAttachment(100,-197)
    drive_base.turn(135)
    drive_base.straight(1300)
    drive_base.straight(-40)
    drive_base.turn(-49)
    drive_base.straight(80)
    drive_base.straight(-200)
    drive_base.turn(90)
    drive_base.straight(300)
    drive_base.turn(150)
    drive_base.straight(200)
    drive_base.straight(-180)
    drive_base.turn(-95)
    drive_base.straight(450)
    drive_base.turn()
    drive_base.straight()
    drive_base.stop()

run2()